package com.supplytrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class SupplyTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplyTrackApplication.class, args);
	}

}
